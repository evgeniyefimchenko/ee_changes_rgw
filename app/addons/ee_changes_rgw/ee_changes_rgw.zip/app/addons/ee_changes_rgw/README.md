﻿ee_changes_rgw - модуль вносит изменения на сайт согласно ТЗ

Разработка модуля для платформы CS CART согласно предоставленного задания:

1) шоурум https://yadi.sk/d/kKhsn8OlQnBSeQ

2) блок мотивации https://yadi.sk/i/r_fRWtBzCc7osQ

3) слайдер на карточке https://yadi.sk/i/iWXkKpofkGBc7g